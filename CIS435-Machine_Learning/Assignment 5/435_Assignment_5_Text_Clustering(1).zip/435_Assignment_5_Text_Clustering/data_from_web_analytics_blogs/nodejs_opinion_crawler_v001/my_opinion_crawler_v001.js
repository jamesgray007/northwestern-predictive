// a JavaScript Web crawler that runs from node.js

// Management question: What is ______ saying about Twitter?
// ______ is specified as a search URL at the end of the program listing

// To see what major Web analytics sites say about Twitter
// we use the string "Twitter" (lower- or upper-case)
// within a regular expression search
// and we use a set of organizational URLs

// first install node.js from  http://nodejs.org/
// then install the crawler package from outside the node shell
// using the node package manager (npm) by typing
//   npm install crawler  [it may take a couple minutes to install]

// run this JavaScript program from a working directory by typing
//   node my_crawler_v001.js
// crawler documentation at https://npmjs.org/package/crawler
var Crawler = require("crawler").Crawler;

// use the fs package for writing to files
var fs = require("fs");

var nfile = 0;  // initialize file counter for file names

var c = new Crawler({
"maxConnections":10,

// callback for each crawled page
"callback":function(error,result,$) {
  if(result) {
    var page = result.body;
    // match regular expression for /string/... upper- or lower-case letters
    //
    // ENTER YOUR SEARCH STRING HERE IN PLACE OF Twitter
    var res = page.match(/Twitter/i); 
    //
    if (res && res.length > 0) {  // this is a hit page... it matches the string
       console.log(result.body);
       // also write result to external file after incrementing file count
       nfile = nfile + 1;
       fs.writeFile("my_twitter_text_" + nfile + ".html", result.body, function(err) {
        if (err) {
          console.log(err);
          } else {
            console.log("\n\n----- FILE SAVED: my_twitter_text_" + nfile + ".html\n");            
            }
        });       
      }
    }
    
  // $ is a jQuery instance scoped to server-side DOM of page
  $("a").each(function(index,a) {
    console.log(a.href);
    c.queue(a.href);
    });
  }  
});

// this is the Web site home page to start the crawl
//
// ENTER YOUR SEARCH URL HERE
c.queue("http://cutroni.com/");  // crawling this Web site