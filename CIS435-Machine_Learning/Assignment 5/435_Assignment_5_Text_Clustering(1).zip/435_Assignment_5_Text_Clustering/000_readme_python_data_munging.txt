readme_python_data_munging.txt

We demonstrate how to use Python to extract the text within pages and save that text into 297 text files for further analysis. (Note that the names of these files include the word "twitter," but these are not Twitter data. These are data from the web analytics opinion blogs.)

The input directory is <452_Session7_Individual_Assignment_Data> which we generated earlier using our node.js crawler.

The Python text processing program is <452_get_text_v003.py>.

The output from the Python program are the text files in the directory <results>. These files can serve as input to  programs for sentiment analysis. (Examples of programs for sentiment are shown in chapter 8 of my textbook. Those programs in my book are written in R.)

Note that if you work with the example we have been setting up here, there is no need to run the Python program <452_get_text_v003.py>.  All you need going forward are the text files located in the <results> subdirectory.

The challenge from here is to develop a program for analyzing the resulting text files. 
