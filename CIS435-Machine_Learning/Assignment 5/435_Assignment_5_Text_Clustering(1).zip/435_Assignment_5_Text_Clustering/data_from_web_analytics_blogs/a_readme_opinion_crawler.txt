To gather the data for our study of opinion, we looked for blogs devoted to analytics. We found a site listing what it called "12 Must Read Analytics Blogs":

http://blog.crazyegg.com/2013/02/22/best-analytics-blogs/

We crawled selected web sites in the area of web analytics and SEO, collecting a number of opinion pages. These pages cover a variety of topics. There are more than 200 pages gathered from the sites. 

Ten of the twelve blogs or opinion sites/pages remain operational and permitted the crawl:

1. Analytics Talk (Justin Cutroni)
http://cutroni.com/

2. Crazy Egg
http://blog.crazyegg.com/category/analytics/

3. SEO Takeaways (Himanshu Sharma)
http://www.seotakeaways.com/

4. Hubspot
http://blog.hubspot.com/?Tag=marketing+analytics

5. KISSmetrics
http://blog.kissmetrics.com/?s=analytics

6. Mixpanel
http://blog.mixpanel.com/2012/12/17/bs-metrics/

7. Occam's Razor (Avinash Kaushik)
http://www.kaushik.net/avinash/

8. Online Behavior
http://online-behavior.com/

9. Search Engine Watch
http://searchenginewatch.com/analytics

10. Web Analytics World
http://www.webanalyticsworld.net/

We used our node.js crawler to crawl each of these site. The resulting directories numbered v001 through v010 correspond to each of the above opinion sites. 

The first task is to parse the data into text documents for analysis. 

After the documents are ready for analysis, we can employ methods of text and sentiment analysis, as illustrated in code from chapters 7 and 8 of my textbook.

What can we say about a selected topic in web analytics judging from the documents we obtained from these ten sources?  

[Note. For those who have been successful in using Web crawlers from the previous assignment, feel free to develop your own research question and gather your own data for analysis.]



